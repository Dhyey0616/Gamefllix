<?php 
include("../includes/db.php");
include '../includes/compression.php';

extract($_POST);

$thumb1 =  $_FILES['cat_img']['name'];
if($thumb1!=''){
	$thumb = rand(100, 999) . $thumb1;
	
// $thumb = rand(100, 999) .  $_FILES['cat_img']['name'];
@$thumbpath = "../upload/subcat/" . $thumb;
move_uploaded_file($_FILES['cat_img']['tmp_name'], $thumbpath);
compress(@$thumbPath, @$thumbPath,90);
}
else
{
	$thumb='';
}
//SELECT `id`, `cat_id`, `name`, `sc_img`, `description` FROM `sub_category` WHERE 1


$disc=$aboutdes;
$text = str_replace("'", "\'", $disc);


	 $sql = "INSERT INTO  sub_category set cat_id='$cat',name='$name',description='$text',sc_img='$thumb' ";

// $inr = mysqli_query($con,$in);
	$result = mysqli_query($con, $sql) or die(mysqli_error($con));
	if($result>0)
	{

		echo "<script>alert('Sub Category added successfully.');
		window.location.href='../add_subcategory.php';
		</script>";
	}
	else
	{
		echo "<script>alert('please add proper data');</script>";
	}




?>