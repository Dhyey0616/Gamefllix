<?php
include("../includes/db.php");

extract($_POST);

$uid = $_GET['uid'];
$prid = $_GET['prid'];

  $sel_banner = mysqli_query($con,"select * from add_imge where id='$uid' ");
  $banner_sel = mysqli_fetch_array($sel_banner);
  $fe_img = $banner_sel['img'];

  $banner =  $_FILES['banner']['name'];
  $fmgg = $fe_img;



if(strlen($_FILES['banner']['name']) != 0) {

$newThumb =  $_FILES['banner']['name'];
// 	$newThumb =  rand(100, 999) . $_FILES['banner']['name'];
	$thumbPath = "../upload/add/" . $newThumb;
	move_uploaded_file($_FILES['banner']['tmp_name'], $thumbPath);
	$fmgg = $newThumb;
	unlink("../upload/add/" . $fe_img);
}


$sql = "update add_imge set add_image='$fmgg' where id=$uid";
$result = mysqli_query($con, $sql) or die(mysqli_error($con));

//  header('location: ../logo_list.php');
if($result>0)
{
	echo "<script>alert('Product updated successfully.');
	window.location.href='../add_update.php?uid=$prid';
	</script>";
}
else
{
	echo "<script>alert('please add proper data');</script>";
}
?>