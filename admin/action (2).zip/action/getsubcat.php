<?php 
include("../includes/db.php");

if (! empty($_POST["cat"]))
{
	$cat = $_POST['cat'];
	$query = "select * from  sub_category WHERE cat_id='$cat'";
	$r = mysqli_query($con,$query);
	while ($prr = mysqli_fetch_array($r))
	{
		$sub_name = $prr['name'];
		$sc_id = $prr['id'];
		?>
		<option value="<?php echo $sc_id;?>"><?php echo $sub_name;?></option>
		<?php
		
	}
}
?>