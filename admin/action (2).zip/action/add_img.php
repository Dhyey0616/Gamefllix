<?php 
include("../includes/db.php");
include '../includes/compression.php';

extract($_POST);


$last = $_GET['pid'];
$i = 0;


    
    if(in_array("", $_FILES['image']['name']))
                            {
                            $im='';
                            //echo "<script>alert('no aviyu');</script>";
                            }else{
                            
                           
                            $Images = $_FILES["image"];
                            
                            $TotalFiles = count($Images["name"]);
                            $TmpImg = array();
                            
                            for($i=0; $i<$TotalFiles; $i++ ) {
                            $ImageName =  rand(100, 999) . $Images["name"][$i];
                            $ImagePath = "../upload/add/" . $ImageName;
                            array_push($TmpImg, $ImageName);
                            
                            move_uploaded_file($Images["tmp_name"][$i], $ImagePath);
                            // compress(@$ImagePath, @$ImagePath,80);

                           
                            }
                            // $im = implode(",",$TmpImg);
                            
                            }
                            
 foreach($TmpImg as $TmpImg1){
     
     
  $sql = "insert into add_imge set add_id='$last',add_image='$TmpImg1' ";
$result = mysqli_query($con, $sql) or die(mysqli_error($con));
$i = 1;

 }
 
 if($i==1)
 {
     	echo "<script>alert('Product added successfully.');
	window.location.href='../display_add.php';
	</script>";
 }
 
else
{
	echo "<script>alert('please add proper data');
	window.location.href='../display_add.php';
	</script>";
}

?>